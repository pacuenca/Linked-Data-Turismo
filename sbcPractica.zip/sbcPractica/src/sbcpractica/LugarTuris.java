package sbcpractica;

/**
 *
 * @author pacuenca
 */
public class LugarTuris {
    String RUC;
    String actividad;
    String clasificacion;
    String categoria;
    String sectorTuristico;
    String ciudad;
    String provincia;
    String pais;
    String referencia;
    String administracionZonal;
    String cantidadHabitacion;
    String cantidadCama;
    String cantidadMesa;
    String direccion;
    String latitud;
    String longitud;
    String telefono;
    String email;
    String webBlog;
    String tipoLugar;
    String legalName;

    public LugarTuris(String RUC, String actividad, String clasificacion, String categoria, String sectorTuristico, String ciudad, String provincia, String pais, String referencia, String administracionZonal, String cantidadHabitacion, String cantidadCama, String cantidadMesa, String direccion, String latitud, String longitud, String telefono, String email, String webBlog, String tipoLugar, String legalName) {
        this.RUC = RUC;
        this.actividad = actividad;
        this.clasificacion = clasificacion;
        this.categoria = categoria;
        this.sectorTuristico = sectorTuristico;
        this.ciudad = ciudad;
        this.provincia = provincia;
        this.pais = pais;
        this.referencia = referencia;
        this.administracionZonal = administracionZonal;
        this.cantidadHabitacion = cantidadHabitacion;
        this.cantidadCama = cantidadCama;
        this.cantidadMesa = cantidadMesa;
        this.direccion = direccion;
        this.latitud = latitud;
        this.longitud = longitud;
        this.telefono = telefono;
        this.email = email;
        this.webBlog = webBlog;
        this.tipoLugar = tipoLugar;
        this.legalName = legalName;
    }

    public LugarTuris() {
    }

    public String getRUC() {
        return RUC;
    }

    public void setRUC(String RUC) {
        this.RUC = RUC;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSectorTuristico() {
        return sectorTuristico;
    }

    public void setSectorTuristico(String sectorTuristico) {
        this.sectorTuristico = sectorTuristico;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = "Ecuador";
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getAdministracionZonal() {
        return administracionZonal;
    }

    public void setAdministracionZonal(String administracionZonal) {
        this.administracionZonal = administracionZonal;
    }

    public String getCantidadHabitacion() {
        return cantidadHabitacion;
    }

    public void setCantidadHabitacion(String cantidadHabitacion) {
        this.cantidadHabitacion = cantidadHabitacion;
    }

    public String getCantidadCama() {
        return cantidadCama;
    }

    public void setCantidadCama(String cantidadCama) {
        this.cantidadCama = cantidadCama;
    }

    public String getCantidadMesa() {
        return cantidadMesa;
    }

    public void setCantidadMesa(String cantidadMesa) {
        this.cantidadMesa = cantidadMesa;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebBlog() {
        return webBlog;
    }

    public void setWebBlog(String webBlog) {
        this.webBlog = webBlog;
    }

    public String getTipoLugar() {
        return tipoLugar;
    }

    public void setTipoLugar(String tipoLugar) {
        this.tipoLugar = tipoLugar;
    }

    public String getLegalName() {
        return legalName;
    }

    public void setLegalName(String legalName) {
        this.legalName = legalName;
    }
    
    
}

