/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbcpractica;

// import org.apache.jena.rdf.model.OntModel;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.RDFNode;
import javax.swing.table.DefaultTableModel;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import java.util.Scanner;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author pacuenca
 */
public class Consultas {

    public static JTable table;

    public static void drawUI() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
        JFrame frame;
        frame = new JFrame();
        JScrollPane scrollPane;
        // JToolBar toolBar;
        frame.setBounds(100, 100, 585, 413);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        frame.getContentPane().add(toolBar, BorderLayout.NORTH);

        JButton btnHelp = new JButton("Data");
        JButton btnFind = new JButton("BUSCAR");
        JButton btnClear = new JButton("Clear");
        toolBar.add(btnHelp);
        toolBar.add(btnFind);
        toolBar.add(btnClear);

        scrollPane = new JScrollPane();
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        //Right here you just set the table headers
        String[] header = {"s", "p", "o", "o2", "o3", "o4", "aa", "bb"};
        //Creating the tablemodel with no data , 'null', and give the tablemodel the header
        DefaultTableModel model;
        model = new DefaultTableModel(null, header);
        model = new DefaultTableModel(null, header);
        table = new JTable(model);
        scrollPane.setViewportView(table);
        frame.setVisible(true);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
//Find a list of companies filtered by some criteria and return DBpedia URIs of them

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
//        String var1 = (String) actividad.getSelectedItem();
        System.out.println("Ingrese un nombre;");
        Scanner entrada = new Scanner(System. in);
        
        String var = null;
        
        var=entrada.nextLine();
        System.out.println(var);
        String s1 = "http://localhost:8890/sparql";
        String q1 = "PREFIX dbo: <http://dbpedia.org/ontology/> "
                + "PREFIX voc: <http://turismo.org/voc/> "
                + "PREFIX schema: <http://schema.org/> "
                + "PREFIX foaf: <http://xmlns.com/foaf/0.1/> "
                + "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> "
                + "SELECT ?s ?o ?p ?o2 ?o3 ?o4 "
                + "FROM <http://data.utpl.edu.ec/LugaresTuristicos> "
                + "WHERE { "
                + "?a dbo:city \"" + var + "\". "
                + "?a foaf:name ?s. "
                + "?a voc:actividad ?y. "
                + "?y rdfs:label ?o; voc:clasificacion ?p; voc:categoria ?o2. "
                + "?a voc:tipoOrganizacion ?o3; schema:address ?o4 "
                + "}";
        System.out.println(q1);
        QueryExecution e1 = QueryExecutionFactory.sparqlService(s1, q1);
        ResultSet results1 = e1.execSelect();
        drawUI();
        while (results1.hasNext()) {
            QuerySolution sol = results1.nextSolution();
            RDFNode subject = sol.get("s");
            RDFNode object = sol.get("o");
            RDFNode predicate = sol.get("p");
            RDFNode obje = sol.get("o2");
            RDFNode obje2 = sol.get("o3");
            RDFNode obje3 = sol.get("o4");

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.addRow(new Object[]{subject, object, predicate, obje, obje2, obje3});
        }
        e1.close();
    }
}
