/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbcpractica;

/**
 *
 * @author Florcita
 */
public class Curso {
    String curso;
    String cod;
    String name;
    int edad;
    String genero;
    String interes;
    String organizacion;

    public Curso() {
    }

    public Curso(String curso, String cod, String name, int edad, String genero, String interes, String organizacion) {
        this.curso = curso;
        this.cod = cod;
        this.name = name;
        this.edad = edad;
        this.genero = genero;
        this.interes = interes;
        this.organizacion = organizacion;
    }
    
    

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getInteres() {
        return interes;
    }

    public void setInteres(String interes) {
        this.interes = interes;
    }

    public String getOrganizacion() {
        return organizacion;
    }

    public void setOrganizacion(String organizacion) {
        this.organizacion = organizacion;
    }

}
