package sbcpractica;

import java.io.BufferedReader;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.apache.jena.vocabulary.DC;
import org.apache.jena.vocabulary.DC;
import org.apache.jena.vocabulary.SKOS;
import org.apache.jena.vocabulary.VCARD;
import org.apache.jena.sparql.vocabulary.FOAF;
import org.apache.jena.rdf.model.RDFWriter;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;
import static org.apache.jena.enhanced.BuiltinPersonalities.model;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ResourceFactory;
import static sbcpractica.Practica.cursos;

/**
 *
 * @author pacuenca
 */
public class JenaTurismo {
    public static final String SEPARATOR = ";";
    public static final String SEPARATOR2 = ",";
    public static final ArrayList<LugarTuris> lugares= new ArrayList<LugarTuris>();
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File fi = new File("C:\\Users\\Florcita\\Documents\\NetBeansProjects\\sbcPractica\\src\\csvcsv2.csv");
        StringTokenizer st;
        Scanner entrada = null;
        String sCadena;
        try {
            entrada = new Scanner(fi);
            while (entrada.hasNext()) {
                LugarTuris p = new LugarTuris();
                sCadena = entrada.nextLine();
//                System.out.println(sCadena);
                st = new StringTokenizer(sCadena, ";");
                while (st.hasMoreTokens()) {
                    p.setRUC(st.nextToken());
                    p.setLegalName(st.nextToken());
                    p.setActividad(st.nextToken());
                    p.setClasificacion(st.nextToken());
                    p.setCategoria(st.nextToken());
                    p.setTipoLugar(st.nextToken());
                    p.setProvincia(st.nextToken());
                    p.setCiudad(st.nextToken());
                    p.setReferencia(st.nextToken());
                    p.setDireccion(st.nextToken());
                    p.setTelefono(st.nextToken());
                    p.setEmail(st.nextToken());
                    p.setWebBlog(st.nextToken());
                    p.setCantidadHabitacion(st.nextToken());
                    p.setCantidadCama(st.nextToken());
                    p.setCantidadMesa(st.nextToken());
                    p.setLatitud(st.nextToken());
                    p.setLongitud(st.nextToken());
                    p.setAdministracionZonal(st.nextToken());
                    p.setSectorTuristico(st.nextToken());
                }
                lugares.add(p);

            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            entrada.close();
        }

        for (int i = 0; i < lugares.size(); i++) {
            System.out.println(lugares.get(i).getRUC());
            System.out.println(lugares.get(i).getLegalName()); 
            System.out.println(lugares.get(i).getLatitud());
            System.out.println(lugares.get(i).getLongitud());
        }
        ///////////CREAMOS URIS DE ONTOLOGIAS Y D ELOS DATOS
        
         //create an empty Model
        Model model = ModelFactory.createDefaultModel();
        File f = new File("C:\\Users\\Florcita\\Documents\\NetBeansProjects\\sbcPractica\\src\\archivoRDF.rdf"); //Fijar ruta donde se creará el archivo RDF
        FileOutputStream os = new FileOutputStream(f);
        System.out.println("hola estoy x aquio");
        //Fijar Prefijo para URI base de dos datos a crear 
        String voc = "http://turismo.org/voc/";
        model.setNsPrefix("voc",voc);
        
        String schema = "http://schema.org/";
        model.setNsPrefix("schema",schema);
        
        String dbo = "http://dbpedia.org/ontology/";
        model.setNsPrefix("dbo", dbo);
        
        String dbr = "http://dbpedia.org/resource/";
        model.setNsPrefix("dbr", dbr);
        
        String dataPrefix = "http://example.org/data/";
        model.setNsPrefix("data", dataPrefix);
        
        //Fijar prefijos de vocabularios incorporados en Jena
        String foaf = "http://xmlns.com/foaf/0.1/";
        model.setNsPrefix("foaf", foaf);
        
         // en el caso de vocabularios externos (no incorporados en Jena) se debe crear un modelo
        Model dboModel = ModelFactory.createDefaultModel();  // modelo para la ontología
        //uris y valores para conceptos
        String lugarTuristicoClassURI = voc+"LugarTuristico";
        String CityClassURI = dbo+"City";
        String ProvinceClassURI = dbo+"Province";
        String CountryClassURI = dbo+"Country";
        String ActividadClassURI = voc+"Actividad";
        String BienesClassURI = voc+"Bienes";
        String PlaceClassURI = schema+"Place";
        String ContactPointClassURI = schema+"ContactPoint";
        String GeoCoordinatesClassURI = schema+"GeoCoordinates";

        //uris y valores para propiedades
        String managePropertiURI = voc+"manage";
        String rucPropertiURI = voc+"ruc";
        String activityPropertiURI = voc+"actividad";
        String adminZonalPropertiURI = voc+"administracionZonal";
        String sectorTurisPropertiURI = voc+"sectorTuristico";
        String cityPropertiURI = dbo+"city";
        String referenciaPropertiURI = voc+"referencia";
        String ownsPropertiURI = schema+"owns";
        String provincePropertiURI = dbo+"province";
        String countryPropertiURI = dbo+"country";
        String addressPropertiURI = schema+"address";
        String geoPropertiURI = schema+"geo";
        String latitudePropertiURI = schema+"latitude";
        String longitudePropertiURI = schema+"longitude";
        String tipoOrgPropertiURI = voc+"tipoOrganizacion";
        String categoriaPropertiURI = voc+"categoria";
        String clasificacionPropertiURI = voc+"clasificacion";
        String areaServedPropertiURI = schema+"areaServed";
        String emailPropertiURI = schema+"email";
        String telephonePropertiURI = schema+"telephone";
        String cantHabitacionPropertiURI = voc+"cantHabitacion";
        String cantCamaPropertiURI = voc+"cantCama";
        String cantMesaPropertiURI = voc+"cantMesa";
        

        
        //Creación de clases
        Resource LugarTuristico = ResourceFactory.createResource(lugarTuristicoClassURI);
        
        //Creación de propiedades
        Property manage = ResourceFactory.createProperty(managePropertiURI);
        Property ruc = ResourceFactory.createProperty(rucPropertiURI);
        Property actividad = ResourceFactory.createProperty(activityPropertiURI);
        Property administracionZonal = ResourceFactory.createProperty(adminZonalPropertiURI);
        Property sectorTuristico = ResourceFactory.createProperty(sectorTurisPropertiURI);
        Property city = ResourceFactory.createProperty(cityPropertiURI);
        Property referencia = ResourceFactory.createProperty(referenciaPropertiURI);
        Property owns = ResourceFactory.createProperty(ownsPropertiURI);
        Property province = ResourceFactory.createProperty(provincePropertiURI);
        Property country = ResourceFactory.createProperty(countryPropertiURI);
        Property address = ResourceFactory.createProperty(addressPropertiURI);
        Property geo = ResourceFactory.createProperty(geoPropertiURI);
        Property latitude = ResourceFactory.createProperty(latitudePropertiURI);
        Property longitude = ResourceFactory.createProperty(longitudePropertiURI);
        Property tipoOrganizacion = ResourceFactory.createProperty(tipoOrgPropertiURI);
        Property categoria = ResourceFactory.createProperty(categoriaPropertiURI);
        Property clasificacion = ResourceFactory.createProperty(clasificacionPropertiURI);
        Property areaServed = ResourceFactory.createProperty(areaServedPropertiURI);
        Property email = ResourceFactory.createProperty(emailPropertiURI);
        Property telephone = ResourceFactory.createProperty(telephonePropertiURI);
        Property cantHabitacion = ResourceFactory.createProperty(cantHabitacionPropertiURI);
        Property cantCama = ResourceFactory.createProperty(cantCamaPropertiURI);
        Property cantMesa = ResourceFactory.createProperty(cantMesaPropertiURI);
        
        String var="LugarTurismo";
        for (int i = 0; i < lugares.size(); i++) {
            //Creando el modelo de lugra turistico
            Resource LugarTurismo = model.createResource(dbo + lugares.get(i).getLegalName())
                    .addProperty(RDF.type, model.createResource(lugarTuristicoClassURI))
                    .addProperty(FOAF.name, lugares.get(i).getLegalName())
                    .addProperty(ruc, lugares.get(i).getRUC())
                    .addProperty(actividad, model.createResource(ActividadClassURI+ "/Actividad" + i))
                    .addProperty(administracionZonal, lugares.get(i).getAdministracionZonal())
                    .addProperty(sectorTuristico, lugares.get(i).getSectorTuristico())
                    .addProperty(city, dboModel.getResource(dbo + lugares.get(i).getCiudad()))
                    .addProperty(referencia, lugares.get(i).getReferencia())
                    .addProperty(owns, model.createResource(BienesClassURI+ "/Bienes" + i))
                    .addProperty(areaServed, model.createResource(ContactPointClassURI + "/ContactPoint" + i))
                    .addProperty(address, lugares.get(i).getDireccion())
                    .addProperty(geo, model.createResource(GeoCoordinatesClassURI + "/GeoCoordinates" + i))
                    .addProperty(tipoOrganizacion, lugares.get(i).getTipoLugar())
                    .addProperty(FOAF.weblog, lugares.get(i).getWebBlog());
            Resource Actividad = model.createResource(ActividadClassURI+ "/Actividad" + i)
                    .addProperty(categoria, lugares.get(i).getCategoria())
                    .addProperty(clasificacion, lugares.get(i).getClasificacion())
                    .addProperty(RDFS.label, lugares.get(i).getActividad());
            Resource Bienes = model.createResource(BienesClassURI+ "/Bienes" + i)
                    .addProperty(cantHabitacion, lugares.get(i).getCantidadHabitacion())
                    .addProperty(cantCama,lugares.get(i).getCantidadCama())
                    .addProperty(cantMesa, lugares.get(i).getCantidadMesa());
            Resource City = model.createResource(dbo + lugares.get(i).getCiudad())
                    .addProperty(RDF.type, model.createResource(CityClassURI))
                    .addProperty(province, dboModel.getResource(dbo + lugares.get(i).getProvincia()));
            Resource Province = model.createResource(dbo + lugares.get(i).getProvincia())
                    .addProperty(RDF.type, model.createResource(ProvinceClassURI))
                    .addProperty(country, dboModel.getResource(dbr + "Ecuador"));  
            Resource ContacPoint = model.createResource(ContactPointClassURI + "/ContactPoint" + i)
                    .addProperty(email, lugares.get(i).getEmail())
                    .addProperty(telephone, lugares.get(i).getTelefono());  
            Resource GeoCoordinates = model.createResource(GeoCoordinatesClassURI + "/GeoCoordinates" + i)
                    .addProperty(latitude, schema + lugares.get(i).getLatitud())
                    .addProperty(longitude, schema + lugares.get(i).getLongitud());
            System.out.println("llegue aqui");
            
            // list the statements in the Model
        StmtIterator iter = model.listStatements();
        // print out the predicate, subject and object of each statement
        while (iter.hasNext()) {
            Statement stmt = iter.nextStatement();  // get next statement
            Resource subject = stmt.getSubject();     // get the subject
            Property predicate = stmt.getPredicate();   // get the predicate
            RDFNode object = stmt.getObject();      // get the object

            System.out.print(subject.toString());
            System.out.print(" " + predicate.toString() + " ");
            if (object instanceof Resource) {
                System.out.print(object.toString());
            } else {
                // object is a literal
                System.out.print(" \"" + object.toString() + "\"");
            }

            System.out.println(" .");
        }

        // now write the model in XML form to a file
        System.out.println("MODELO RDF------");
        model.write(System.out, "RDF/XML-ABBREV");

        // Save to a file
        RDFWriter writer = model.getWriter("RDF/XML"); //RDF/XML
        writer.write(model, os, "");
        }
        

        //Cerrar modelos
        dboModel.close();

        model.close();
        

    }
}
